package com.example.notesapp;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class EditorActivity extends AppCompatActivity {

    private EditText etTitle, etContent;
    private NotesDatabaseHelper dbHelper;
    private Note currentNote;
    private boolean isEditing = false;
    private int selectedColorIndex = 0;
    private View[] colorDots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        dbHelper = new NotesDatabaseHelper(this);
        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setupColorPicker();

        long noteId = getIntent().getLongExtra("note_id", -1);
        if (noteId != -1) {
            isEditing = true;
            currentNote = dbHelper.getNoteById(noteId);
            etTitle.setText(currentNote.getTitle());
            etContent.setText(currentNote.getContent());
            selectedColorIndex = currentNote.getColorIndex();
            setTitle("Edit Catatan");
            updateEditorBackground();
            highlightSelectedDot();
        } else {
            setTitle("Catatan Baru");
            updateEditorBackground();
        }
    }

    private void setupColorPicker() {
        colorDots = new View[]{
            findViewById(R.id.dot0), findViewById(R.id.dot1),
            findViewById(R.id.dot2), findViewById(R.id.dot3),
            findViewById(R.id.dot4), findViewById(R.id.dot5)
        };

        for (int i = 0; i < colorDots.length; i++) {
            final int idx = i;
            colorDots[i].setOnClickListener(v -> {
                selectedColorIndex = idx;
                updateEditorBackground();
                highlightSelectedDot();
            });
        }
        highlightSelectedDot();
    }

    private void updateEditorBackground() {
        int color = NoteAdapter.CARD_COLORS[selectedColorIndex % NoteAdapter.CARD_COLORS.length];
        findViewById(R.id.editorRoot).setBackgroundColor(color);
    }

    private void highlightSelectedDot() {
        for (int i = 0; i < colorDots.length; i++) {
            colorDots[i].setAlpha(i == selectedColorIndex ? 1.0f : 0.4f);
            colorDots[i].setScaleX(i == selectedColorIndex ? 1.3f : 1.0f);
            colorDots[i].setScaleY(i == selectedColorIndex ? 1.3f : 1.0f);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        if (item.getItemId() == R.id.action_save) { saveNote(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void saveNote() {
        String title = etTitle.getText().toString().trim();
        String content = etContent.getText().toString().trim();

        if (title.isEmpty()) {
            etTitle.setError("Judul tidak boleh kosong");
            etTitle.requestFocus();
            return;
        }

        if (isEditing) {
            currentNote.setTitle(title);
            currentNote.setContent(content);
            currentNote.setColorIndex(selectedColorIndex);
            dbHelper.updateNote(currentNote);
            Toast.makeText(this, "✅ Catatan diperbarui!", Toast.LENGTH_SHORT).show();
        } else {
            Note note = new Note(title, content, selectedColorIndex);
            dbHelper.insertNote(note);
            Toast.makeText(this, "✅ Catatan disimpan!", Toast.LENGTH_SHORT).show();
        }

        setResult(RESULT_OK);
        finish();
    }
}
